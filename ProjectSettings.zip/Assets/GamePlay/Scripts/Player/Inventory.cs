using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory
{
    public static int quantity = 0;
    public static int nutsQuantity = 0;
}
