using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponMelee : MonoBehaviour
{
    // Start is called before the first frame update    
    public float damage = 0;
    public bool impacted = false;
}
