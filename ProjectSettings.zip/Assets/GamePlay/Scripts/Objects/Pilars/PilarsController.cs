using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PilarsController : BaseGame
{
    public List<GameObject> crystals = new List<GameObject>();
}
